var searchData=
[
  ['time_0',['time',['../structload__balancer.html#a2d277d8aa6f23f826b6400368c998c4c',1,'load_balancer']]],
  ['time_5farrival_1',['time_arrival',['../structrequest.html#a21a5fe8e67cdbc34c1802a2818cbaaa8',1,'request']]],
  ['time_5fprocessed_2',['time_processed',['../structrequest.html#a79a3907f18d7858783c7af729923d5f3',1,'request']]],
  ['total_5frun_5ftime_3',['total_run_time',['../structload__balancer.html#a254e81c25117a7587ed220ee21826956',1,'load_balancer']]]
];
