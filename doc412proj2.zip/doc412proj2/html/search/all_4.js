var searchData=
[
  ['last_5frequest_5ftime_0',['last_request_time',['../structwebserver.html#ac8d7e58e57d0daf6b71ef796fb9ac20f',1,'webserver']]],
  ['load_5fbalancer_1',['load_balancer',['../structload__balancer.html',1,'load_balancer'],['../structload__balancer.html#a6696192649af33c439ecc8054c809a58',1,'load_balancer::load_balancer()']]]
];
