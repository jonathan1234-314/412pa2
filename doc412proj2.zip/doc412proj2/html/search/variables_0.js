var searchData=
[
  ['current_5frequest_0',['current_request',['../structwebserver.html#aa8bf4789958ecbd492525f8a97c506d3',1,'webserver']]]
];
