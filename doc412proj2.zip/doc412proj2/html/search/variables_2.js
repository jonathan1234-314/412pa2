var searchData=
[
  ['last_5frequest_5ftime_0',['last_request_time',['../structwebserver.html#ac8d7e58e57d0daf6b71ef796fb9ac20f',1,'webserver']]]
];
